# Artefactos de revisión · Sesión en vivo KPKN

Abre **prototipos.html** en un navegador. Es autocontenido y funciona sin internet.

- A: tarjetas refinadas.
- B: lista vertical con acordeones.
- C: lista con editor fijo, propuesta experimental.
- Comparar: la misma sesión en las tres propuestas.
- Estado: 38 casos de registro, detalle, preparación, cardio, medios y sheets.

Editar un borrador y cambiar de vista lo conserva. Cambiar el estado de demostración o recargar reinicia el ejemplo. Cámara, voz, análisis y guardado están simulados.

**Ninguna vista está elegida o aprobada.** El plan está en [PLAN-PROVISIONAL.md](PLAN-PROVISIONAL.md). Las imágenes están en `capturas/` y el resultado de las verificaciones web en `VERIFICACION.md`.

Fuentes de edición: `index.template.html`, `styles.css`, `app.js`. `node build.cjs` genera el HTML e incluye los recursos de KPKN desde el repositorio. `node serve.cjs` lo sirve exclusivamente en http://127.0.0.1:8769. El HTML portable no depende de ese servidor.
