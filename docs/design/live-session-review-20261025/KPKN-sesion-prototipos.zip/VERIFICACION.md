# Verificación del prototipo web

26 de octubre de 2026. Verificación realizada en el navegador integrado, sobre el HTML generado.

| Comprobación | Resultado observado |
|---|---|
| Sintaxis JavaScript | `node --check app.js` completado correctamente. |
| Generación portable | `node build.cjs` produce `prototipos.html` con tipografías, ilustración y código incluidos. |
| 38 escenas × tres vistas | Las 114 combinaciones se renderizan, con contenido y sin desbordamiento horizontal del contenedor del teléfono. Recorrido mediante el selector de estado. Evidencia: `qa-smoke.json`. |
| Consola del navegador | Sin errores ni avisos en el recorrido de las escenas. |
| Esfuerzo requerido | Pulsar Registrar sin marcar esfuerzo muestra «Marca tu esfuerzo antes de registrar». |
| Borrador compartido | Introducir `102,5` kg en Lista y elegir RIR 2; cambiar a Foco conserva ambos valores. |
| Registro y deshacer | Registrar pasa de 2 a 3 series completadas; Deshacer vuelve a 2. |
| Actualizar | Editar carga de una serie ya registrada y actualizar conserva el contador en 2; aparece el aviso de actualización sin duplicado. |
| Formato compacto | En 360 × 740 y texto 130 %, las tres vistas mantienen el botón de registrar dentro del teléfono y las cifras comprobadas sin recorte horizontal. |
| Capturas | Nueve láminas guardadas. Composición revisada visualmente en registro, avanzado, medios, movilidad, descanso, aproximaciones y sheets. |

Se corrigieron durante la revisión: recorte de cifras largas, selección fuera del contexto visible en Foco, alineación del checklist, posición del detalle abierto en Lista y capturas tomadas durante la transición de entrada.

Estas comprobaciones cubren presentación y flujos seleccionados. No certifican todas las combinaciones de interacción ni una implementación nativa. Cámara, voz, análisis, cardio, calibración y guardado usan datos/acciones de demostración. No hubo compilación Android, instalación, cambios de esquema, uso del dispositivo ni validación física.

Los archivos creados para esta entrega se encuentran únicamente en `docs/design/live-session-review-20261025/`. El plan identifica el trabajo de readiness/cierre que deberá reconciliarse cuando se decida implementar.
