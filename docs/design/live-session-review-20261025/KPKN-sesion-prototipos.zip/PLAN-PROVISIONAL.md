# KPKN · Sesión en vivo · Propuesta para revisar

**Estado: exploración visual. Ninguna vista está elegida ni aprobada.**

Esta entrega contiene prototipos y un itinerario de implementación condicionado a la revisión de esos prototipos. No modifica la aplicación Android. Entrega revisada el 26 de octubre de 2026; carpeta iniciada el 25.

## Abrir los artefactos

- [Comparador interactivo](prototipos.html): A, B y C comparten la misma sesión de demostración. Editar una vista y cambiar a otra conserva el borrador.
- [Tarjetas refinadas](prototipos.html?view=cards).
- [Lista con acordeones](prototipos.html?view=list).
- [Foco: lista y editor estable](prototipos.html?view=focus).
- El selector **Estado** permite revisar 38 situaciones. Pantalla: 393 × 852, 360 × 740 y 412 × 1007. Texto: 100 % o 130 %.

Los enlaces locales funcionan abriendo `prototipos.html` en un navegador. El HTML contiene sus tipografías, ilustración, estilos y lógica; no necesita conexión. Cambiar de estado o reiniciar reconstruye el ejemplo. No hay persistencia al recargar.

## Tres hipótesis, sin un ganador impuesto

| Propuesta | Qué cambia | Ventaja que buscamos comprobar | Coste que debemos revisar |
|---|---|---|---|
| **A · Tarjetas** | Refina la tarjeta de tamaño estable: carga, repeticiones, esfuerzo y acciones de detalle. Conserva las caras Avanzado y Modo visual. | Lectura clara y familiaridad. Una serie mantiene el protagonismo. | Necesita más navegación para consultar otras series. |
| **B · Lista** | Registro vertical de toda la sesión, agrupado por ejercicio; una serie abre su editor en la propia fila. | Cambiar de serie y comparar registros sin recorrer tarjetas. | Al expandir un detalle se desplaza el contenido siguiente. |
| **C · Foco** | Mantiene la lista de contexto arriba y un editor estable abajo, junto al control de registrar. Seleccionar una fila cambia el contenido del editor. | Evitar que el lugar donde se registra cambie al abrir un acordeón; reducir desplazamientos del pulgar y conservar el contexto. | El editor ocupa altura permanente y deja menos filas visibles. En pantallas cortas hay que desplazar la lista. |

C es mi propuesta experimental para competir con A y B. Su hipótesis es mejorar velocidad, estabilidad y contexto al mismo tiempo. **No hay evidencia para afirmar que sea superior en todo sentido**: esa conclusión necesita probar las tareas y discutir sus costes. Puede sobrevivir una vista, varias, o una combinación de partes. Este plan no fija cuál.

## Identidad y decisiones visuales propuestas

- Negro como fondo, módulos en carbón, texto crema y secundarios cálidos. **Sin texto amarillo.** El estado activo se reconoce por forma, contraste y una línea lateral, además del texto.
- Syne para cifras y títulos; Inter para lectura y controles. Se incluyen las fuentes locales de KPKN, no sustitutos de un sistema web.
- Cifras de carga protagonistas. Unidades pequeñas pero próximas a su dato. Divisores finos, pocos contenedores y sombras contenidas.
- Controles propios, sin adoptar como identidad el aspecto por defecto de Material/Compose. La implementación nativa puede usar sus primitivas de accesibilidad y composición.
- La tarjeta conserva su marco al cambiar entre registro, Avanzado y Modo visual. Cuando aumenta el contenido, se desplaza dentro de su región; no empuja el control de registrar.
- Ilustración de Caupolicán existente en el repositorio, usada sin modificar. En cámara y álbum representa material de demostración.

## Header y control inferior

**Header en dos niveles.** La isla superior reúne sesión, avance y tiempo. El contexto del ejercicio queda debajo: nombre completo, equipo, etiquetas y acceso a voz. Así se conserva la sencillez visual de la referencia sin esconder el ejercicio ni llenar la isla de métricas. Las etiquetas pertenecen al ejercicio; el menú superior pertenece a la sesión. El tiempo abre sus controles.

**Stepper inferior.** La base de la referencia aportada se traduce en cuatro segmentos, avance global y posición dentro del ejercicio. Registrar es la acción principal; las flechas navegan sin registrar. Tocar el avance abre el recorrido de la sesión. El texto del botón responde a movilidad, aproximaciones, serie, descanso o feedback. El descanso puede minimizarse sin perder el borrador.

La referencia usa abreviaturas; el prototipo ofrece nombres accesibles completos. Los segmentos no deben confundir «serie seleccionada» con «series realmente registradas». El contador global usa solamente series efectivas del ejemplo.

## Qué se puede revisar realmente

| Familia | Estados y acciones del prototipo |
|---|---|
| Registro | Carga editable, repeticiones/cantidad, RIR/RPE explícito, historial, etiquetas, guardar, actualizar el mismo registro y deshacer. |
| Modalidades | Repeticiones, RM/Training Max, solo RPE, tiempo, distancia, unidad propia, AMRAP y propósito calibrador. |
| Carga y lados | Carga externa, corporal, lastre, asistencia; selección y borradores por lado en unilateral. |
| Detalle | Parciales separadas de completas, ayuda, ROM, notas y error de ejecución distinto del fallo muscular. |
| Técnicas | Drop-set, rest-pause, myo-reps, selección/edición de tramos, recorrido guiado y finalización parcial. |
| Preparación | Checklist de movilidad, movimiento, articulaciones, aproximaciones y descanso de aproximación. |
| Sesión | Superserie de ejemplo, recorrido por ejercicio, descanso normal/extra/minimizado, cardio continuo/intervalos y feedback. |
| Medios | Modo visual, expansión, ficha, álbum, captura simulada, progreso y resultado no concluyente del análisis. |
| Sheets | Readiness y cierre reconstruidos como referencia del trabajo existente. |

La comparación mantiene el mismo estado en las tres columnas. En preparación, cardio y descanso, B coloca el contenido en el flujo de la lista y C en su panel fijo; A conserva el marco de tarjeta.

**Límites de este artefacto:** datos sintéticos; cámara, micrófono, análisis, cardio y guardado son simulaciones de interacción. No se accede al teléfono ni se mide rendimiento físico. El resultado de calibración es una muestra estática, no un cálculo del motor. La maqueta web no demuestra compatibilidad Android, restauración tras muerte del proceso, persistencia, TalkBack ni comportamiento del teclado nativo.

## Readiness y cierre: respetar el trabajo existente

La referencia examinada es el commit **b3a057e13**, disponible en `post-rings-v3` / `.worktrees/post-rings`, con `WorkoutReadinessSheet.kt` y `RecordedSessionFinishSheet.kt`. No debe asumirse que ya está integrado en la rama principal.

Se conserva la estructura de readiness —energía, sueño, estrés, DOMS, molestias y voz— y la de cierre —Resumen, Progreso, Anotaciones, esfuerzo de sesión opcional, compartir y guardar—. Las reproducciones HTML sirven para revisar continuidad; no se presentan como capturas nativas ni como sustituciones aprobadas.

Sugerencias que quedan abiertas: continuidad de encabezados/espaciado con el nuevo registro, jerarquía de la acción final y claridad entre esfuerzo de una serie y esfuerzo opcional de sesión. Cualquier cambio en esos sheets necesita discutirse sobre la versión real y conservar sus contratos de datos.

## Plan de implementación, después de decidir el diseño

### 1. Cerrar la dirección visual sobre los artefactos

Revisar A, B y C con las mismas tareas. Anotar qué partes se conservan: tipo de registro, header, stepper, densidad, esfuerzo, parciales y detalle avanzado. No asignar una vista por defecto hasta que se decida. Salida: lista explícita de decisiones y capturas que la respalden.

Tareas sugeridas: registrar 100 × 8 con RIR 2; cambiar a 102,5 kg; corregir una serie guardada; registrar ambos lados; agregar dos parciales; editar un drop-set; abrir historial y volver; iniciar/minimizar descanso; recorrer readiness y completar sesión. Medir tiempo, errores, desplazamientos y claridad, sin inventar resultados de usabilidad.

### 2. Reconciliar la base y proteger el comportamiento

Antes de editar Android, comprobar rama, WIP y presencia efectiva del trabajo b3a057e13. No sobrescribir cambios concurrentes ni integrar automáticamente una rama. Fijar una base común para las pruebas y el alcance aprobado.

Puntos de referencia examinados: `SetExecutionCard.kt`, `LiveSessionCardFrame.kt`, `LiveSessionLine.kt` y los modelos `WorkoutSetDraft` / `WorkoutSetExecutionRef`. La línea activa es `LiveSessionLine`, no el antiguo cockpit. Revalidar estos puntos cuando comience la implementación porque el repositorio está en movimiento.

### 3. Compartir el estado antes de añadir representaciones

Separar el borrador y los eventos de ejecución de la representación de la tarjeta. Mantener una sola fuente de verdad por identidad de ejecución, aparición de ejercicio, serie y lado. Las vistas consumen ese estado y emiten eventos; no escriben Room directamente.

Preservar las cadenas en edición —vacío y separador decimal incluidos—, campos opcionales, progreso de técnica, notas y medios. Cambiar vista no debe registrar, perder campos, reiniciar descanso ni duplicar registros. Mantener el contrato de esfuerzo explícito: el esfuerzo planificado no se convierte en esfuerzo realizado.

### 4. Implementar la composición que se acuerde

Introducir componentes KPKN compartidos para header, metadatos, carga/cantidad, esfuerzo, acciones y stepper. Refactorizar con cambios pequeños y comparables. Implementar únicamente las vistas elegidas; el prototipo no obliga a mantener tres arquitecturas.

Conservar `LiveSessionCardFrame` para la tarjeta estable y las identidades/índices reales del recorrido. No sintetizar páginas que pierdan lados, rondas o callbacks. Prever teclado, insets, cambio de orientación, retorno de medios y restauración del borrador.

No se propone una migración de base de datos por cambiar la presentación. Si la implementación descubre una necesidad de persistencia adicional, se documentará y revisará antes de tocar el esquema.

### 5. Verificar el comportamiento y la fidelidad nativa

Pruebas focalizadas del estado y de los contratos que cambien: borrador por serie/lado; esfuerzo requerido y rangos RIR/RPE; cantidades y separador decimal; actualizar frente a crear; deshacer; técnica parcial; AMRAP/calibrador; transición y minimización del descanso.

Después, compilar con el wrapper del repositorio y realizar QA de las variantes aprobadas en tamaños compactos y texto aumentado, navegación, TalkBack, teclado y reanudación. Si corresponde al Z Flip, usar únicamente **KPKN Dev / com.example.kpkn.dbg**, con `phone_run` y `phone.lock`, firma y datos verificados. Esa validación futura no forma parte de esta entrega web.

### 6. Revisión final del diseño implementado

Comparar capturas nativas con los artefactos acordados, comprobar las variantes de la matriz y cerrar diferencias explícitamente. Compilación, pruebas, instalación y aceptación visual se reportan como evidencias separadas. No hay autorización implícita de publicación o de integración por haber aprobado un prototipo.

## Decisiones que siguen abiertas

Qué vista o combinación conservar; si ofrecer un selector permanente; comportamiento inicial de acordeones; densidad del editor fijo; esfuerzo compacto frente a escala completa; grado de simplificación del header; interacción exacta del stepper; ajustes opcionales a readiness/cierre. Ninguna se da por aprobada en este documento.
